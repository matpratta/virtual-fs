gcc main.c -o ./bin/projeto
chmod +x ./bin/projeto
./bin/projeto