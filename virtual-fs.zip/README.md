# Sistema de Arquivos Virtual

Este projeto foi desenvolvido para a matéria Sistemas Operacionais II do curso de Segurança da Informação da Fatec Americana.

## Compilando

Durante o desenvolvimento foi utilizado apenas o comando `gcc` para compilar o programa. Ele deve compilar normalmente também no CodeBlocks, porém não foi testado.

`gcc main.c -o ./projeto` no Linux ou `gcc main.c -o ./projeto.exe` no Windows.

## Autores

Matheus Pratta
Lucia Casati
João Leite